// نواة مشتركة: تهيئة Firebase مرة واحدة + دوال مساعدة للتطبيقات الثلاثة
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import * as A from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import * as F from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { firebaseConfig, STATUS } from "./firebase-config.js";

export { A, F, STATUS };
export const app = initializeApp(firebaseConfig);          // نفس المشروع ونفس قاعدة البيانات للجميع
export const auth = A.getAuth(app);
export const db = F.getFirestore(app);

// ---------- أدوات ----------
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const money = (n) => `${Number(n || 0).toLocaleString('en-US')} ج.م`;
export const toEnDigits = (s) => String(s || '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
export const normPhone = (p) => toEnDigits(p).replace(/\D/g, '');
export const validPhone = (p) => /^01[0125]\d{8}$/.test(normPhone(p));
export const fmtTime = (ts) => ts?.toDate ? ts.toDate().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : '';

export function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div'); t.id = 'toast';
    t.className = 'fixed top-4 left-1/2 -translate-x-1/2 z-[100] bg-slate-900 text-white text-sm font-bold px-5 py-3 rounded-full shadow-2xl border border-amber-400 max-w-[90vw] text-center transition-opacity';
    document.body.appendChild(t);
  }
  t.textContent = msg; t.style.opacity = 1;
  clearTimeout(t._h); t._h = setTimeout(() => t.style.opacity = 0, 3500);
}

export function badge(status) {
  const c = status === STATUS.NEW ? 'bg-amber-100 text-amber-800'
    : status === STATUS.DONE ? 'bg-emerald-100 text-emerald-800'
    : status === STATUS.CANCELED ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-800';
  return `<span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${c}">${esc(status)}</span>`;
}

// ---------- الدخول برقم الهاتف + PIN (يُحوَّل داخلياً لبريد/كلمة مرور في Firebase Auth) ----------
const phoneEmail = (phone) => `${normPhone(phone)}@souq-alsho3la.app`;
const pinPass = (pin) => `${toEnDigits(pin)}-souq`;            // Firebase يشترط 6 أحرف على الأقل
export const validPin = (pin) => /^\d{4}$/.test(toEnDigits(pin));

export async function registerUser({ role, name, phone, pin, address = '' }) {
  const cred = await A.createUserWithEmailAndPassword(auth, phoneEmail(phone), pinPass(pin));
  await F.setDoc(F.doc(db, 'users', cred.user.uid), {
    role, name, phone: normPhone(phone), address,
    approved: role === 'customer',                              // المندوب ينتظر موافقة المدير
    createdAt: F.serverTimestamp()
  });
  return cred.user;
}
export const loginUser = (phone, pin) => A.signInWithEmailAndPassword(auth, phoneEmail(phone), pinPass(pin));
export const logout = () => A.signOut(auth);

export async function getProfile(uid) {
  const s = await F.getDoc(F.doc(db, 'users', uid));
  return s.exists() ? s.data() : null;
}

export function authErr(e) {
  const m = {
    'auth/email-already-in-use': 'هذا الرقم مسجل بالفعل، سجّل دخولك',
    'auth/invalid-credential': 'الرقم أو الرمز السري غير صحيح',
    'auth/user-not-found': 'لا يوجد حساب بهذا الرقم',
    'auth/wrong-password': 'الرمز السري غير صحيح',
    'auth/too-many-requests': 'محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة',
    'auth/network-request-failed': 'تأكد من اتصال الإنترنت',
    'auth/operation-not-allowed': 'فعّل Email/Password من Firebase Authentication',
    'auth/api-key-not-valid.-please-pass-a-valid-api-key.': 'بيانات Firebase في firebase-config.js غير صحيحة',
    'permission-denied': 'ليس لديك صلاحية لهذا الإجراء (راجع قواعد Firestore)'
  };
  return m[e?.code] || `حدث خطأ: ${e?.code || e?.message || e}`;
}
