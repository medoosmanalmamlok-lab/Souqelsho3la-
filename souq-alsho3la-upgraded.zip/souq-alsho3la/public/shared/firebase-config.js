// ============================================================
//  إعداد واحد مشترك للتطبيقات الثلاثة (العميل - المندوب - المدير)
//  الصق هنا بيانات مشروعك من: Firebase Console ▸ Project settings ▸ Your apps ▸ Web app
// ============================================================
export const firebaseConfig = {
  apiKey: "AIzaSyB0jgKHlkkzrbrxSSBwJAdjZQBVVSIZCY4",
  authDomain: "souqelsho3la-56b14.firebaseapp.com",
  projectId: "souqelsho3la-56b14",
  storageBucket: "souqelsho3la-56b14.firebasestorage.app",
  messagingSenderId: "214332084184",
  appId: "1:214332084184:web:06c8516210414fe3aaecad",
  measurementId: "G-5MHCJE11JZ"
};

// بريد المدير (للتحقق في الواجهة فقط - الحماية الحقيقية في firestore.rules عن طريق UID)
export const ADMIN_EMAIL = "PASTE_ADMIN_EMAIL";

export const WHATSAPP = "201126202684";   // رقم واتساب المتجر (بصيغة دولية)
export const DELIVERY_FEE = 15;
export const CATEGORIES = ['خضروات', 'فواكه', 'مجمدات', 'لحوم', 'ماركت'];
export const STATUS = { NEW: 'جديد', ON_WAY: 'جاري التوصيل', DONE: 'تم التسليم', CANCELED: 'ملغي' };
