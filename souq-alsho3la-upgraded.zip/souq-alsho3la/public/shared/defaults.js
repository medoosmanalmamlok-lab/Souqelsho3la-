export const DEFAULT_PRODUCTS = [
  { name: 'طماطم بلدي طازجة', category: 'خضروات', price: 15, unit: 'كيلو', stock: 120, image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400', description: 'طماطم فاخرة من مزارع الوادي الجديد' },
  { name: 'بطاطس تحمير ممتازة', category: 'خضروات', price: 20, unit: 'كيلو', stock: 200, image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400', description: 'بطاطس مقرمشة جودة عالية' },
  { name: 'بصل أحمر واحاتي', category: 'خضروات', price: 18, unit: 'كيلو', stock: 150, image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cf?w=400', description: 'بصل ممتاز شديد الحفظ' },
  { name: 'موز بلدي طازج', category: 'فواكه', price: 25, unit: 'كيلو', stock: 80, image: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?w=400', description: 'موز حلو المذاق غني بالفيتامينات' },
  { name: 'بلح واحاتي خصب فاخر', category: 'فواكه', price: 40, unit: 'كيلو', stock: 300, image: 'https://images.unsplash.com/photo-1596591606975-97ee5cef3a1e?w=400', description: 'أجود أنواع البلح الساير والخصب بالخارجة' },
  { name: 'دواجن طازجة مجمدة 1كجم', category: 'مجمدات', price: 125, unit: 'القطعة', stock: 50, image: 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=400', description: 'دواجن مذبوحة وفق الشريعة الإسلامية' },
  { name: 'لحم بلدي طازج (كندوز)', category: 'لحوم', price: 380, unit: 'كيلو', stock: 25, image: 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?w=400', description: 'لحوم بلدي مذبوحة يومياً تحت إشراف بيطري' },
  { name: 'زيت طهي ممتاز 1 لتر', category: 'ماركت', price: 65, unit: 'زجاجة', stock: 90, image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400', description: 'زيت طهي نقاوة ممتازة' }
];
