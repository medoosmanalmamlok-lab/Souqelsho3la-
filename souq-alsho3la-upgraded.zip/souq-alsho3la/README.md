# سوق الشعلة — 3 تطبيقات ويب على Firebase واحد

| التطبيق | المسار | الملف |
|---|---|---|
| العميل | `/` | `public/index.html` |
| المندوب | `/driver/` | `public/driver/index.html` |
| المدير | `/admin/` | `public/admin/index.html` |

الثلاثة تستخدم `public/shared/` (نفس المشروع، نفس Auth، نفس Firestore) — فيظهر الطلب عند المندوب والمدير لحظياً.

## خطوات التشغيل (مرة واحدة)
1. **Firebase Console** ▸ أنشئ مشروعاً ▸ أضف **Web app** ▸ انسخ الـ config والصقه في `public/shared/firebase-config.js`.
2. **Authentication** ▸ Sign-in method ▸ فعّل **Email/Password** (الدخول بالهاتف + PIN يعمل فوقه).
3. **Firestore Database** ▸ Create database (production mode).
4. **Authentication ▸ Users ▸ Add user**: أنشئ حساب المدير ببريدك وكلمة مرور قوية الآن (قبل نشر الموقع)، ثم:
   - ضع البريد في `ADMIN_EMAIL` داخل `firebase-config.js`
   - انسخ **User UID** والصقه مكان `PASTE_ADMIN_UID` في `firestore.rules`
5. انشر:
   ```
   npm i -g firebase-tools
   firebase login
   firebase use --add        # اختر مشروعك
   firebase deploy           # ينشر الـ rules والمواقع الثلاثة
   ```
6. ادخل `/admin/` ▸ تبويب المنتجات ▸ **استيراد المنتجات الافتراضية**.

## سير العمل
- العميل: تسجيل بالهاتف + PIN ▸ يطلب ▸ يتابع حالة طلباته فقط.
- المندوب: يقدّم طلب انضمام ▸ المدير يوافق من تبويب «المناديب» ▸ يقبل الطلبات (Transaction يمنع قبول مندوبين لنفس الطلب) ▸ يؤكد التسليم.
- المدير: الطلبات والحالات، المنتجات (إضافة/تعديل/حذف)، موافقة المناديب، إحصائيات.

## ملاحظات أمان
- PIN من 4 أرقام ضعيف نسبياً؛ Firebase يحدّ المحاولات المتكررة، ويمكن رفعه لـ 6 أرقام بتغيير `validPin` و`maxlength`.
- إجمالي الطلب يُحسب في متصفح العميل؛ للحماية الكاملة من التلاعب بالأسعار استخدم Cloud Function تعيد حسابه.
- لا ترفع `firebase-config.js` الحقيقي لمستودع عام دون ضبط قيود API key من Google Cloud Console.
